// Make sure mealtime data can be added and retrieved properly.
// Tests for valid input, missing ratios, default times, and multiple entries.

package monitoring;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Map;

class MealtimeEditorTest {

    @Test
    public void testValidUpdate() {
        MealtimeEditor editor = new MealtimeEditor();
        editor.updateMealtime("johndoe", "08:00 AM", 15);
        Map<String, Integer> meals = editor.getUserMeals("johndoe");
        assertEquals(15, meals.get("08:00 AM"));
    }

    @Test
    public void testMissingCarbToUnitRatio() {
        MealtimeEditor editor = new MealtimeEditor();
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            editor.updateMealtime("johndoe", "08:00 AM", 0);
        });
        assertEquals("Carb-to-unit ratio must be a positive number.", exception.getMessage());
    }

    @Test
    public void testDefaultMealtime() {
        MealtimeEditor editor = new MealtimeEditor();
        editor.updateMealtime("johndoe", "00:00 AM", 15);
        Map<String, Integer> meals = editor.getUserMeals("johndoe");
        assertEquals(15, meals.get("00:00 AM"));
    }

    @Test
    public void testMultipleMealtimes() {
        MealtimeEditor editor = new MealtimeEditor();
        editor.updateMealtime("johndoe", "08:00 AM", 15);
        editor.updateMealtime("johndoe", "12:00 PM", 10);

        Map<String, Integer> meals = editor.getUserMeals("johndoe");
        assertEquals(15, meals.get("08:00 AM"));
        assertEquals(10, meals.get("12:00 PM"));
    }
}
