// Validates account creation process.
// Check for successful creation, invalid email format, and password mismatch.

package monitoring;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class AccountCreatorTest {

    @Test
    public void testValidAccountCreation() {
        System.out.println("Testing valid account creation...");
        UserService service = new UserService();
        AccountCreator creator = new AccountCreator(service);
        boolean result = creator.createAccount("John", "Doe", "johndoe", "Password123", "Password123", "johndoe@example.com", "01/01/1990");
        System.out.println("Account creation result: " + result);
        assertTrue(result);
    }

    @Test
    public void testInvalidEmail() {
        System.out.println("Testing account creation with invalid email...");
        UserService service = new UserService();
        AccountCreator creator = new AccountCreator(service);
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            creator.createAccount("John", "Doe", "johndoe", "Password123", "Password123", "johndoe", "01/01/1990");
        });
        System.out.println("Exception message: " + exception.getMessage());
        assertEquals("Invalid email format. Please enter a valid email address.", exception.getMessage());
    }

    @Test
    public void testMismatchedPasswords() {
        System.out.println("Testing account creation with mismatched passwords...");
        UserService service = new UserService();
        AccountCreator creator = new AccountCreator(service);
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            creator.createAccount("John", "Doe", "johndoe", "Password123", "Password456", "johndoe@example.com", "01/01/1990");
        });
        System.out.println("Exception message: " + exception.getMessage());
        assertEquals("Passwords do not match.", exception.getMessage());
    }
}
