// Check login functionality of UserService.
// Tests valid login, invalid credentials, empty fields, and session behavior.

package monitoring;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class login {

    private UserService userService;
    private Account acc;

    @BeforeEach
    public void setup() {
        userService = new UserService();
        acc = new Account("John", "Doe", "johndoe", "email@email.com", "August 8th");
        userService.register("johndoe", "Password123", acc);
    }

    @Test
    public void testSuccessfulLogin() {
        System.out.println("Testing successful login...");
        boolean result = userService.login("johndoe", "Password123");
        System.out.println("Expected: true, Actual: " + result);
        assertTrue(result);
    }

    @Test
    public void testLoginWithInvalidUsername() {
        System.out.println("Testing login with invalid username...");
        boolean result = userService.login("notexist", "Password123");
        System.out.println("Expected: false, Actual: " + result);
        assertFalse(result);
    }

    @Test
    public void testLoginWithIncorrectPassword() {
        System.out.println("Testing login with incorrect password...");
        boolean result = userService.login("johndoe", "WrongPassword");
        System.out.println("Expected: false, Actual: " + result);
        assertFalse(result);
    }

    @Test
    public void testLoginWithEmptyFields() {
        System.out.println("Testing login with empty fields...");
        boolean result = userService.login("", "");
        System.out.println("Expected: false, Actual: " + result);
        assertFalse(result);
    }

    @Test
    public void testLoginAlreadyLoggedInSession() {
        System.out.println("Testing login with already logged-in session...");
        boolean first = userService.login("johndoe", "Password123");
        boolean second = userService.login("johndoe", "Password123");
        System.out.println("First login: " + first + ", Second login attempt (should fail): " + second);
        assertTrue(first);
        assertFalse(second);
    }

    @Test
    public void testRetrieveAdherenceDataAfterLogin() {
        System.out.println("Testing adherence data retrieval after login...");
        userService.login("johndoe", "Password123");
        String data = userService.getAdherenceData("johndoe");
        System.out.println("Adherence data: " + data);
        assertNotNull(data);
    }

    @Test
    public void testLoginRedirectsToCorrectPage() {
        System.out.println("Testing redirect page after login...");
        userService.login("johndoe", "Password123");
        String page = userService.getRedirectPage("johndoe");
        System.out.println("Expected: dashboard, Actual: " + page);
        assertEquals("dashboard", page);
    }
}
