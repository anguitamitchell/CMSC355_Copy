// Verify authentication logic.
// Tests for correct and incorrect credentials, empty fields,
// and registering new user and authenticating them.

package monitoring;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class Authentication {

    private UserService userService;
    private Account acc;

    @BeforeEach
    public void setup() {
        userService = new UserService();
        acc = new Account("John", "Doe", "johndoe", "email@email.com", "August 8th");
        userService.register("johndoe", "Password123", acc);
    }

    @Test
    public void testSuccessfulAuthentication() {
        System.out.println("Testing hardcoded successful authentication...");
        assertTrue(userService.authenticate("alice", "Secret123"));
    }

    @Test
    public void testAuthenticationWithInvalidUsername() {
        System.out.println("Testing authentication with invalid username...");
        assertFalse(userService.authenticate("bob", "Secret123"));
    }

    @Test
    public void testAuthenticationWithWrongPassword() {
        System.out.println("Testing authentication with wrong password...");
        assertFalse(userService.authenticate("alice", "WrongPass"));
    }

    @Test
    public void testAuthenticationWithEmptyFields() {
        System.out.println("Testing authentication with empty fields...");
        assertFalse(userService.authenticate("", ""));
    }

    @Test
    public void testAuthenticationAfterRegistration() {
        System.out.println("Testing authentication after new registration...");
        Account newAccount = new Account("Test", "User", "newuser", "new@user.com", "01/01/2000");
        userService.register("newuser", "NewPass456", newAccount);
        assertTrue(userService.authenticate("newuser", "NewPass456"));
    }
}
