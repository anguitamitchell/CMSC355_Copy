// This represents a user account with basic profile info.
// Has first name, last name, username, email, date of birth, and password.
package monitoring;

public class Account {
    private String firstName;
    private String lastName;
    private String username;
    private String email;
    private String dob;
    private String password;

    public Account(String firstName, String lastName, String username, String email, String dob) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.username = username;
        this.email = email;
        this.dob = dob;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPassword() {
        return password;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getUsername() {
        return username;
    }

    public String getEmail() {
        return email;
    }

    public String getDoB() {
        return dob;
    }
}
