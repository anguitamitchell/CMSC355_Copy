// Saves and loads mealtime data to/from file.
package monitoring;

import com.google.gson.reflect.TypeToken;
import com.google.gson.Gson;

import java.io.*;
import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.Map;

public class MealtimeStorage {
    private static final String FILE_PATH = "src/main/resources/data/mealtimes.json";
    private static final Gson gson = new Gson();

    public static Map<String, Map<String, Integer>> loadMealtimes() {
        File file = new File(FILE_PATH);
        if (!file.exists()) {
            return new HashMap<>();
        }

        try (Reader reader = new FileReader(file)) {
            Type type = new TypeToken<Map<String, Map<String, Integer>>>() {}.getType();
            return gson.fromJson(reader, type);
        } catch (IOException e) {
            e.printStackTrace();
            return new HashMap<>();
        }
    }

    public static void saveMealtimes(Map<String, Map<String, Integer>> meals) {
        try (Writer writer = new FileWriter(FILE_PATH)) {
            gson.toJson(meals, writer);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
