// Used to create new user accounts.
// Validation for email format & matching passwords before registering account.
// Uses UserService to save new user.
package monitoring;

public class AccountCreator {
    private UserService loginDatabase;

    public AccountCreator(UserService database) {
        this.loginDatabase = database;
    }

    public boolean createAccount(String firstName, String lastName, String username, String password, String confirmPassword, String email, String dob) {
        if (!email.contains("@") || !email.contains(".")) {
            throw new IllegalArgumentException("Invalid email format. Please enter a valid email address.");
        }

        if (!password.equals(confirmPassword)) {
            throw new IllegalArgumentException("Passwords do not match.");
        }

        Account account = new Account(firstName, lastName, username, email, dob);
        loginDatabase.register(username, password, account);
        return true;
    }
}
