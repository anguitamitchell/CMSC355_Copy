// Allow user to update and retrieve mealtime ratios.
// Stores data in mem and uses MealtimeStorage to save to disk.
package monitoring;

import java.util.HashMap;
import java.util.Map;

public class MealtimeEditor {
    private Map<String, Map<String, Integer>> userMeals;

    public MealtimeEditor() {
        userMeals = MealtimeStorage.loadMealtimes();
    }

    public void updateMealtime(String username, String mealtime, int ratio) {
        if (ratio <= 0) {
            throw new IllegalArgumentException("Carb-to-unit ratio must be a positive number.");
        }
        if (mealtime == null || mealtime.isEmpty()) {
            throw new IllegalArgumentException("Mealtime cannot be empty.");
        }

        userMeals.putIfAbsent(username, new HashMap<>());
        userMeals.get(username).put(mealtime, ratio);
        MealtimeStorage.saveMealtimes(userMeals);
    }

    public Map<String, Integer> getUserMeals(String username) {
        return userMeals.getOrDefault(username, new HashMap<>());
    }
}
